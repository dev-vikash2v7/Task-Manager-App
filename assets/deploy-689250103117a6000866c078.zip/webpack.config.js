module.exports = {
devServer: {
 allowedHosts: "all"
  }
};
